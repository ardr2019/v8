import { Component, OnInit, AfterContentInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterContentInit {
  barmode: string;
  totalAngularPackages: any;

  constructor(private http: HttpClient) { 
    this.barmode = "indeterminate";

  }

  ngOnInit() {
  //   this.http.get<any>('https://jsonplaceholder.typicode.com/photos').subscribe(data => {
  //     this.totalAngularPackages = data.total;
  //     console.log(this.totalAngularPackages);     

  // })
  fetch('https://jsonplaceholder.typicode.com/photos')
  .then(response => response.json())
  .then(json => {this.totalAngularPackages = json.thumbnailUrl;})
  }

  public toggleload(){
    console.log("dfd");

    if(this.barmode == 'determinate'){
      this.barmode = "indeterminate";
      console.log("dfd");
    }else
    {
    this.barmode = "determinate";      
    }
  }

  ngAfterContentInit() {
    console.log('determinate');
    this.barmode = "determinate";
  }

}
